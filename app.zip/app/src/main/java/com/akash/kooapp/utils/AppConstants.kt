package com.akash.kooapp.utils

class AppConstants {

    companion object{
        const val BASE_URL = "https://gorest.co.in/public/"
    }
}